well-done
=========

a roguelike or something

descend a well, retrieve its loot, buy stuff from the stores above so that you can descend more

for a local informal 7drl compo that ends 2012-09-09 23:59


how to play
-----------

* use hjklyubn (or numpad, if you're a nub) for movement
* a or numpad 5: [a]pply object on ground (for now, just for going through portals) - use it to enter the well and shops and stuff
* g: [g]et item (in shops, attempts to buy item)
* d: [d]rop item (in shops, sells item)
* e: [e]quip item
* r: [r]emove equipped item, putting it back in inventory
* x: e[x]amine item on ground (good for checking out shop wares)
* i: [i]nspect item in inventory (exactly the same as examine)
* v: in[v]oke item in inventory (for using town portal scrolls, health pots)
* s: [s]leep (do nothing) for 5000 in-game ticks


walkthrough
-----------

start by using your 100 starting gold to buy:
* flimsy mail (from an armor shop)
* knife (from a weapon shop)
* torch (from a general store)

and [e]quip them

then enter the well, kill slimes, collect gold, and go back out

then just buy whatever you want; this game is pretty badly balanced (plus deaths are forgiven so easily it's like they never happened)
